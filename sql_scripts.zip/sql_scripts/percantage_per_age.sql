select
	age,
    count(*) as total_patients,
    sum(outcome) as diabetic_patients,
    round(sum(outcome) * 100 / count(*), 2) as percantage_per_age,
     (SELECT SUM(outcome) FROM diabetes_data) AS all_diabetics
from diabetes_data
group by age
order by diabetic_patients desc, percantage_per_age desc