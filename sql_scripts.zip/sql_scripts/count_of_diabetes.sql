SELECT 
    Age, 
    COUNT(*) AS count
FROM diabetes_data
GROUP BY Age
ORDER BY Age;