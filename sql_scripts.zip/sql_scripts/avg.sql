SELECT 
    AVG(Glucose) AS avg_glucose,
    AVG(BloodPressure) AS avg_blood_pressure,
    AVG(BMI) AS avg_bmi
FROM diabetes_data
WHERE Outcome = 1;  -- Для пациентов с диабетом